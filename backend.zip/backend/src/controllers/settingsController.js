const pool = require('../config/database');

exports.getSettings = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM platform_settings LIMIT 1');
    res.json(result.rows[0] || {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateMusic = async (req, res) => {
  const { music_url } = req.body;
  try {
    await pool.query('UPDATE platform_settings SET music_url = $1 WHERE id = 1', [music_url]);
    res.json({ message: 'Música do site atualizada com sucesso!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
