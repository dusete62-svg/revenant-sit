const pool = require('../config/database');

exports.getAllGroups = async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT g.*, c.name as category_name FROM groups g LEFT JOIN categories c ON g.category_id = c.id ORDER BY g.id DESC'
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createGroup = async (req, res) => {
  const { name, banner_url, platform, invite_link, is_vip, category_id } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO groups (name, banner_url, platform, invite_link, is_vip, category_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [name, banner_url, platform || 'WHATSAPP', invite_link, is_vip || false, category_id || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteGroup = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM groups WHERE id = $1', [id]);
    res.json({ message: 'Grupo removido com sucesso!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
