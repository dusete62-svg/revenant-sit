const express = require('express');
const cors = require('cors');
require('dotenv').config();

const groupController = require('./controllers/groupController');
const settingsController = require('./controllers/settingsController');

const app = express();
app.use(cors());
app.use(express.json());

// Rotas da Plataforma
app.get('/api/settings', settingsController.getSettings);
app.put('/api/settings/music', settingsController.updateMusic);
app.get('/api/groups', groupController.getAllGroups);
app.post('/api/groups', groupController.createGroup);
app.delete('/api/groups/:id', groupController.deleteGroup);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`[SERVER ACTIVE] Backend rodando na porta ${PORT}`));
