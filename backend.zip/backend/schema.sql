CREATE TABLE IF NOT EXISTS platform_settings (
    id SERIAL PRIMARY KEY,
    platform_name VARCHAR(100) DEFAULT 'REVENANT ALLIANCE',
    slogan VARCHAR(255) DEFAULT 'Anonymous Recon Platform',
    copyright_text VARCHAR(100) DEFAULT '©2026 REVENANT ALLIANCE // ALL RIGHTS RESERVED.',
    music_url VARCHAR(255) DEFAULT 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    total_visitors INT DEFAULT 52025
);

CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS groups (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    banner_url VARCHAR(255),
    platform VARCHAR(20) DEFAULT 'WHATSAPP',
    invite_link VARCHAR(255) NOT NULL,
    is_vip BOOLEAN DEFAULT FALSE,
    category_id INT REFERENCES categories(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dados Iniciais
INSERT INTO platform_settings (id, platform_name, slogan) 
VALUES (1, 'REVENANT ALLIANCE', 'Anonymous Recon Platform')
ON CONFLICT (id) DO NOTHING;

INSERT INTO categories (name) 
VALUES ('Entretenimento'), ('Recrutamento'), ('Amizades'), ('Jogos')
ON CONFLICT (name) DO NOTHING;
