import React from 'react';

export default function GroupCard({ group }) {
  return (
    <div className="group-card">
      <div 
        className="card-banner" 
        style={{ backgroundImage: `url(${group.banner_url || 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=600&auto=format&fit=crop'})` }}
      >
        {group.is_vip && <span className="vip-badge">★ VIP</span>}
      </div>
      <div className="card-body">
        <h3>{group.name}</h3>
        <span className="platform-tag">{group.platform || 'WHATSAPP'}</span>
        <a href={group.invite_link} target="_blank" rel="noreferrer" className="btn-join">
          ➜ ACESSAR GRUPO
        </a>
      </div>
    </div>
  );
}
