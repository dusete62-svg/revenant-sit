import React from 'react';

export default function Header({ title, slogan }) {
  return (
    <header className="site-header">
      <div className="brand-section">
        <h1 className="logo-title">{title}</h1>
        <div className="system-status-pill">
          <span className="status-dot"></span>
          <span>SYSTEM ACTIVE · {slogan}</span>
        </div>
      </div>
      <div className="header-socials">
        <a href="https://whatsapp.com" target="_blank" rel="noreferrer" className="social-btn whatsapp">
          WHATSAPP
        </a>
        <a href="https://telegram.org" target="_blank" rel="noreferrer" className="social-btn telegram">
          TELEGRAM
        </a>
      </div>
    </header>
  );
}
