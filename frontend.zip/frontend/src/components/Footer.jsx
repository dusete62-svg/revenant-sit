import React from 'react';

export default function Footer({ ownerName, year }) {
  return (
    <footer className="site-footer">
      <div className="owner-badge">
        <span className="role-tag">DONO</span>
        <span className="owner-name">{ownerName || 'Henrik RKK'}</span>
      </div>
      <p className="copyright">©{year || '2026'} REVENANT ALLIANCE || @Onix • D3v.</p>
    </footer>
  );
}
