import React from 'react';

export default function MusicPlayer({ isPlaying, onToggle }) {
  return (
    <div className="music-player-widget">
      <button 
        className={`music-btn ${isPlaying ? 'playing' : ''}`} 
        onClick={onToggle}
        title={isPlaying ? 'Pausar Música' : 'Tocar Música'}
      >
        {isPlaying ? '🎵' : '🔇'}
      </button>
    </div>
  );
}
