import React from 'react';

export default function StatsBoard({ totalGroups, visitorsToday, totalVisitors }) {
  return (
    <div className="stats-board">
      <div className="stat-card">
        <h3>{totalGroups}</h3>
        <p>TOTAL DE GRUPOS</p>
      </div>
      <div className="stat-card">
        <h3>{visitorsToday ? visitorsToday.toLocaleString() : '279'}</h3>
        <p>VISITANTES HOJE</p>
      </div>
      <div className="stat-card">
        <h3>1</h3>
        <p>ONLINE AGORA</p>
      </div>
      <div className="stat-card">
        <h3>{totalVisitors ? totalVisitors.toLocaleString() : '408'}</h3>
        <p>VISITANTES TOTAL</p>
      </div>
    </div>
  );
}
