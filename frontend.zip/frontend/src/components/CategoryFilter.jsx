import React from 'react';

const categories = ['Todos', 'VIP', 'Entretenimento', 'Recrutamento', 'Amizades', 'Jogos'];

export default function CategoryFilter({ selected, onSelectCategory, searchTerm, onSearchChange }) {
  return (
    <div className="filter-section">
      <div className="search-bar">
        <input 
          type="text" 
          placeholder="[ PESQUISAR GRUPO OU CANAL... ]" 
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
      <div className="category-buttons">
        {categories.map(cat => (
          <button 
            key={cat} 
            className={`cat-btn ${selected === cat ? 'active' : ''}`}
            onClick={() => onSelectCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>
    </div>
  );
}
