import React, { useState, useEffect } from 'react';
import { getSettings, updateMusic, getGroups, createGroup, deleteGroup } from '../services/api';

// Defina sua senha de acesso aqui
const ADMIN_PASSCODE = 'revenantadm01';

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState(false);

  const [musicUrl, setMusicUrl] = useState('');
  const [groups, setGroups] = useState([]);
  const [newGroup, setNewGroup] = useState({
    name: '',
    banner_url: '',
    platform: 'WHATSAPP',
    invite_link: '',
    is_vip: false,
  });

  useEffect(() => {
    // Verifica se já fez login nesta sessão
    const sessionAuth = sessionStorage.getItem('admin_authenticated');
    if (sessionAuth === 'true') {
      setIsAuthenticated(true);
      loadData();
    }
  }, []);

  const handleLogin = (e) => {
    e.preventDefault();
    if (passwordInput === ADMIN_PASSCODE) {
      setIsAuthenticated(true);
      setLoginError(false);
      sessionStorage.setItem('admin_authenticated', 'true');
      loadData();
    } else {
      setLoginError(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('admin_authenticated');
  };

  const loadData = async () => {
    try {
      const settingsData = await getSettings();
      if (settingsData?.music_url) setMusicUrl(settingsData.music_url);

      const groupsData = await getGroups();
      setGroups(groupsData || []);
    } catch (err) {
      console.error('Erro ao carregar dados do admin:', err);
    }
  };

  const handleSaveMusic = async (e) => {
    e.preventDefault();
    await updateMusic(musicUrl);
    alert('Música do site alterada com sucesso!');
  };

  const handleAddGroup = async (e) => {
    e.preventDefault();
    if (!newGroup.name || !newGroup.invite_link) {
      alert('Preencha o nome e o link de convite!');
      return;
    }
    await createGroup(newGroup);
    setNewGroup({ name: '', banner_url: '', platform: 'WHATSAPP', invite_link: '', is_vip: false });
    loadData();
  };

  const handleDeleteGroup = async (id) => {
    if (window.confirm('Tem certeza que deseja apagar este grupo?')) {
      await deleteGroup(id);
      loadData();
    }
  };

  // 1. TELA DE LOGIN FUTURÍSTICA
  if (!isAuthenticated) {
    return (
      <div className="splash-screen">
        <div className="splash-content" style={{ borderColor: 'var(--neon-pink)', boxShadow: '0 0 30px rgba(255, 0, 85, 0.3)' }}>
          <h1 className="splash-title" style={{ color: 'var(--neon-pink)', textShadow: '0 0 15px var(--neon-pink)' }}>
            [ REVENANT ADIMNS ]
          </h1>
          <div className="splash-status" style={{ color: 'var(--neon-cyan)' }}>
            LOGIN ADM
          </div>
          
          <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <input
              type="password"
              placeholder="ENTER PASSCODE..."
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              style={{
                padding: '14px',
                borderRadius: '6px',
                background: '#03050a',
                border: '1px solid var(--neon-pink)',
                color: 'var(--neon-cyan)',
                fontFamily: 'Orbitron, sans-serif',
                fontSize: '1rem',
                textAlign: 'center',
                outline: 'none',
                boxShadow: 'inset 0 0 10px rgba(255, 0, 85, 0.2)'
              }}
            />
            
            {loginError && (
              <span style={{ color: 'var(--neon-pink)', fontSize: '0.85rem', fontWeight: 'bold' }}>
                ✖ ACESSO NEGADO: SENHA INCORRETA
              </span>
            )}

            <button type="submit" className="btn-enter-aveone" style={{ width: '100%', justifyContent: 'center' }}>
              ENTRAR ➜
            </button>
          </form>
        </div>
      </div>
    );
  }

  // 2. PAINEL DE CONTROLE (EXIBIDO APÓS AUTENTICAÇÃO)
  return (
    <div style={{ padding: '40px 20px', maxWidth: '800px', margin: '0 auto', color: '#fff' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-cyan)', paddingBottom: '15px', marginBottom: '30px' }}>
        <h1 style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-cyan)', margin: 0 }}>
          ⚙️ PAINEL DE CONTROLE
        </h1>
        <button 
          onClick={handleLogout}
          style={{ background: 'transparent', color: 'var(--neon-pink)', border: '1px solid var(--neon-pink)', padding: '8px 16px', borderRadius: '4px', cursor: 'pointer', fontFamily: 'Orbitron, sans-serif' }}
        >
          DISCONECTE
        </button>
      </div>

      {/* Alterar Música */}
      <section style={{ background: 'var(--bg-card)', padding: '25px', borderRadius: '10px', marginBottom: '30px', border: '1px solid var(--border-cyan)' }}>
        <h2 style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-pink)', marginTop: 0 }}>🎵 Música Global do Site</h2>
        <form onSubmit={handleSaveMusic}>
          <input
            type="text"
            placeholder="Link direto da música (.mp3)"
            value={musicUrl}
            onChange={(e) => setMusicUrl(e.target.value)}
            style={{ width: '100%', padding: '12px', marginBottom: '15px', borderRadius: '6px', background: '#03050a', border: '1px solid var(--border-cyan)', color: '#fff' }}
          />
          <button type="submit" className="btn-enter-aveone" style={{ padding: '10px 25px', fontSize: '0.9rem' }}>
            SALVAR MÚSICA
          </button>
        </form>
      </section>

      {/* Adicionar Grupo */}
      <section style={{ background: 'var(--bg-card)', padding: '25px', borderRadius: '10px', marginBottom: '30px', border: '1px solid var(--border-cyan)' }}>
        <h2 style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-green)', marginTop: 0 }}>➕ Adicionar Novo Grupo</h2>
        <form onSubmit={handleAddGroup} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <input
            type="text"
            placeholder="Nome do Grupo"
            value={newGroup.name}
            onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
            style={{ padding: '12px', borderRadius: '6px', background: '#03050a', border: '1px solid var(--border-cyan)', color: '#fff' }}
          />
          <input
            type="text"
            placeholder="URL da Imagem do gp"
            value={newGroup.banner_url}
            onChange={(e) => setNewGroup({ ...newGroup, banner_url: e.target.value })}
            style={{ padding: '12px', borderRadius: '6px', background: '#03050a', border: '1px solid var(--border-cyan)', color: '#fff' }}
          />
          <input
            type="text"
            placeholder="Link do grupo (WhatsApp / Telegram)"
            value={newGroup.invite_link}
            onChange={(e) => setNewGroup({ ...newGroup, invite_link: e.target.value })}
            style={{ padding: '12px', borderRadius: '6px', background: '#03050a', border: '1px solid var(--border-cyan)', color: '#fff' }}
          />
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={newGroup.is_vip}
              onChange={(e) => setNewGroup({ ...newGroup, is_vip: e.target.checked })}
            />
            Destaque VIP (Borda e Badge Neon Rosa)
          </label>
          <button type="submit" className="btn-enter-aveone" style={{ padding: '12px', fontSize: '0.9rem' }}>
            CADASTRAR GRUPO
          </button>
        </form>
      </section>

      {/* Lista de Grupos */}
      <section style={{ background: 'var(--bg-card)', padding: '25px', borderRadius: '10px', border: '1px solid var(--border-cyan)' }}>
        <h2 style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--text-main)', marginTop: 0 }}>📋 Grupos Ativos ({groups.length})</h2>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {groups.map((g) => (
            <li key={g.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
              <span>{g.name} {g.is_vip && <strong style={{ color: 'var(--neon-pink)' }}>[VIP]</strong>}</span>
              <button onClick={() => handleDeleteGroup(g.id)} style={{ background: '#ff0055', color: '#fff', border: 'none', padding: '6px 14px', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
                EXCLUIR
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
