import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import StatsBoard from '../components/StatsBoard';
import CategoryFilter from '../components/CategoryFilter';
import GroupCard from '../components/GroupCard';
import Footer from '../components/Footer';
import { getGroups } from '../services/api';

export default function Home() {
  const [groups, setGroups] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadGroups();
  }, []);

  const loadGroups = async () => {
    try {
      const data = await getGroups();
      setGroups(data || []);
    } catch (err) {
      console.error('Erro ao carregar grupos:', err);
    }
  };

  const filteredGroups = groups.filter((g) => {
    const matchesCategory =
      selectedCategory === 'Todos'
        ? true
        : selectedCategory === 'VIP'
        ? g.is_vip
        : g.category_name === selectedCategory;

    const matchesSearch = g.name.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  return (
    <div>
      <Header title="REVENANT ALLIANCE" slogan="Anonymous Recon Platform" />
      <main className="main-container">
        <StatsBoard totalGroups={groups.length} visitorsToday={7479} totalVisitors={52025} />
        
        <CategoryFilter
          selected={selectedCategory}
          onSelectCategory={setSelectedCategory}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
        />

        <div className="groups-grid">
          {filteredGroups.length > 0 ? (
            filteredGroups.map((group) => <GroupCard key={group.id} group={group} />)
          ) : (
            <p style={{ textAlign: 'center', color: 'var(--text-muted)', width: '100%', gridColumn: '1 / -1' }}>
              [ NENHUM GRUPO ENCONTRADO COM OS FILTROS SELECIONADOS ]
            </p>
          )}
        </div>
      </main>
      <Footer ownerName="REVENANT ALLIANCE || Ønix D3v" year="2026" />
    </div>
  );
}
