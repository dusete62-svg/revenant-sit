import React from 'react';

export default function Splash({ onEnter, title }) {
  return (
    <div className="splash-screen">
      <div className="splash-content">
        <h1 className="splash-title">{title}</h1>
        <div className="splash-status">
          SEJA BEM VINDO(A)
        </div>
        <button className="btn-enter-aveone" onClick={onEnter}>
          ➜ ACESSAR PLATAFORMA
        </button>
      </div>
    </div>
  );
}
