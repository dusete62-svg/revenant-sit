const API_URL = 'http://localhost:5000/api';

export const getSettings = async () => {
  const res = await fetch(`${API_URL}/settings`);
  return res.json();
};

export const updateMusic = async (music_url) => {
  const res = await fetch(`${API_URL}/settings/music`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ music_url }),
  });
  return res.json();
};

export const getGroups = async () => {
  const res = await fetch(`${API_URL}/groups`);
  return res.json();
};

export const createGroup = async (groupData) => {
  const res = await fetch(`${API_URL}/groups`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(groupData),
  });
  return res.json();
};

export const deleteGroup = async (id) => {
  const res = await fetch(`${API_URL}/groups/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
